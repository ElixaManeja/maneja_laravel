<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">About</div>

                <div class="panel-body">
                    <p> I Maneja Felix from Laguna Basak Pardo Cebu City. I am second to the last of my
                     siblings and beautiful. I love sing and dance and I love to eat vegetable as well.
                     My favorite color is gray and brown. I love doing something mysterious way and 
                     find someone who love me. My favorite food is fried chicken. I had lot of 
                     experience to do something in myself, just like do the things that I can’t reach,
                     explore  more places within cebu, having fun with other guy that I didn’t know
                     them. I know there are many problem that I face so all I need is to be strong 
                     and have trust for my decision making. I had a lot of plans for my family.<br><br>
                       I want to serve them, give their want and needs. I expect to work with the
                     government because I know I can show my skill how to communicate to other
                     people and act like to be true person not to be untrue. I have a dream to go
                     other country together with my family. I want to my family proud of me of 
                     what those of my decision making to be success. <br><br>

                        I know my situation is very difficult to solve those problem that I face. I won’t to 
                    field them because of the trials that gods give me. My goal to my self is to prove 
                    them that I can reach for my dream to become a web designer and fashion desigener. I 
                    know this is not easy to reach my goal I need to process a lot of things that I 
                    wanted to be learn for my self.<br><br>
                         If I graduate this coming 2018 I think I can do all 
                    of my want and needs to myself. I can travel all over the world if I success to 
                    become a web designer. My promises to myself is to achieve my successful decision 
                    making and prove them that I can do everything in the good way thank you.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>