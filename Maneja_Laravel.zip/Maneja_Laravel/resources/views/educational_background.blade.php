@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Educational Background</div>

                <div class="panel-body">
                    <p>
                        Laguna Basak Pardo Cebu City<br>
09330312716<br>
marchacute86@gmail.com<br>


<br><br><b>Felix S. Maneja</b> <br> <br>                               

<b>PERSONAL DATA</b><br><br>
    Date of Birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; February 13, 1994<br>
    Place of Birth&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;     Cebu City<br>
    Civil Status &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;           Single<br>
    Citizenship&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;        Filipino<br>
    Religion &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;          Catholic<br>
    Father’s Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;      Feliciano Maneja<br>
    Mother’s Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;      Rosemarie Maneja<br><br>


<b>EDUCATIONAL BACKGROUND</b><br><br>
    Primary     Don Vicente Rama Memorial Elementary School<br>
                Macopa St. Cebu City<br><br>

Secondary       Don Vicente Rama Memorial national High School<br>
                Macopa St. Cebu City<br><br>
    
Tertiary        University of Cebu Main Campus (Still Studying)<br>
                Sanciangko St. Cebu City<br><br>

                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
