@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">My Subjects</div>

                <div class="panel-body">
                    <table class="table table-stripped">
                        <th>SCHED-NO</th><th>COURSE-NO</th><th>TIME</th><th>DAYS</th><th>ROOM</th><th>UNITS</th>
                        <tr>
                            <td>IT-13862</td>
                            <td>CAPSTONE 42</td>
                            <td>8:30-11:30 AM</td>
                            <td>SUN</td>
                            <td>537</td>
                            <td>3.0</td>
                        </tr>
                        <tr>
                            <td>IT-24737</td>
                            <td>FREEELPM</td>
                            <td>8:00-9:30 PM</td>
                            <td>TTH</td>
                            <td>530B</td>
                            <td>3.0</td>
                        </tr>
                        <tr>
                            <td>IT-24737</td>
                            <td>PRACTICUM 1</td>
                            <td>1:30-3:00 PM</td>
                            <td>TTH</td>
                            <td>544</td>
                            <td>0.0</td>
                        </tr>
                        <tr>
                            <td>IT-02600</td>
                            <td>ITELECTPHP2(lab)</td>
                            <td>7:31-8:31 PM</td>
                            <td>MWF</td>
                            <td>544</td>
                            <td>0.0</td>
                        </tr><tr>
                            <td>IT-02600</td>
                            <td>ITELECTPHP2(lec)</td>
                            <td>6:31-7:31 PM</td>
                            <td>MWF</td>
                            <td>530A</td>
                            <td>3.0</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>Total Units: </td>
                            <td>9.0</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
